#!/bin/bash

node /app/start.js

pm2 logs
